export class Leave_Status
{
    Leave_Status_Id:number;
    Status_Name:string;



constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

