export class Shore
{
    Shore_Id:number;
    Shore_Name:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

