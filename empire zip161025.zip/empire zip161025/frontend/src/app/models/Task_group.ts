export class Task_Group
{
    Task_Group_Id:number;
    Task_Group_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

