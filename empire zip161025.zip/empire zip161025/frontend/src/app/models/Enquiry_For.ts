export class Enquiry_For
{
    Enquiryfor_Id:number;
    Enquirfor_Name:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

