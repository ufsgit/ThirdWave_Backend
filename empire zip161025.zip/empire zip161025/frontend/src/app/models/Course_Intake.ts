export class Course_Intake
{
Course_Id:number;
Intake_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

