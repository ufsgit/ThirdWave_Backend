export class Sort_By
{
    Sort_By_Id:number;
    Sort_By_Name:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

