export class Application_List {
    
    
    Application_details_Id:number;
    constructor(values: Object = {}) {
        Object.assign(this, values)
    }
}

