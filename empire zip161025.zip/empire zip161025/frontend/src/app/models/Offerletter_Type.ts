export class Offerletter_Type {
    Offerletter_Type_Id:number;
    Offerletter_Type_Name :string;
    constructor(values: Object = {}) {
        Object.assign(this, values)
    }
}

