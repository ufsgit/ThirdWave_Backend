export class Country_Intake_Status
{
Country_Intake_Status_Id:number;
Country_Intake_Status_Name:string;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

