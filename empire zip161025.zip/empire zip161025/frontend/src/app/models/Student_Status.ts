export class Student_Status
{
Student_Status_Id:number;
Student_Status_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

