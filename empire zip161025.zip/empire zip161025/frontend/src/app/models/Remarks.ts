export class Remarks
{
    Remarks_Id:number;
    Remarks_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

