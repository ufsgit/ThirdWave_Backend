
export class User_Sub
{
    User_Sub_Id:number;
    Users_Id:number;
Users_Name:string;
User_Selection_Id:number;
Check_Box:boolean;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

