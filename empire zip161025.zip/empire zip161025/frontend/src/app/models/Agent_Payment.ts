export class Agent_Payment
{
    influencer_payment_id:number;
    Agent_Id:number;
    Agent_Name:string;
    Amount : string; 
    

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

