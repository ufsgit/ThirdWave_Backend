export class Task_Type
{
    Task_Type_Id:number;
    Task_Type_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

