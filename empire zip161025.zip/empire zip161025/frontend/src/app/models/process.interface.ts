export interface Process {
    Process_Name: string;
    process_id_old:number;
    Process_Id: number;
    Order_IN: number;
    Color: string;
    Process_View:Boolean;
    University_Id:number;
    process_ids?: number[]; 
University_Name:string;
  }