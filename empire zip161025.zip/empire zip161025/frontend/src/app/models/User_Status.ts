export class User_Status
{
User_Status_Id:number;
User_Status_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

