export class Duration
{
Duration_Id:number;
Duration_Name:string;
Selection:boolean
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

